module.exports = {
    //url: 'mongodb://10.3.250.144:27017/organChain',
    url: 'mongodb://35.225.48.33:27017/organchain',
    //url: 'mongodb://localhost:27017/organchain',
    blockchain: 'http://ec2-52-53-180-100.us-west-1.compute.amazonaws.com:3000/api/',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    }
};
