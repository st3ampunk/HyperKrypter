Team Name:HyperKrypters

So here we have implemented two ideas that could solve major issue in our current society using BlockChain Technology, both ideas comes under same Domain.
=============================================================
1.Relief Fund Donation:
	Here we have implemented blockchain tech to solve the issue in Donation corruption's where lot's of kind hearted people 
donate to the needy ones who might have facedflood/some crysis, but there is no tracking of this money , if they sent 100Rs only 
10Rs comes to the victim, balance money gets spoiled/eaten by these middle men,The goal here is to build a 3-member 
blockchain application using the coin we built(Hypercoin), consisting of the following entities: an organization representing a 
govt entity, an organization representing an NGO focused on the provision of aid, and an organization representing Global Citizen.
so the donated money is tracked completely and user can know whether it reached those victims or not.

Technology Used:
	Complete Hypercoin built using Python

=============================================================
2.OrganDonation:
	
	A. Problem
Even though the system is designed to be impenetrable to tampering, the system is opaque. If UNOS assigns an organ to someone, 
we just need to trust UNOS that it assigned the organ to the person at the top of the list. This calls for an increase in transparency.

	B. Proposed Solution

The blockchain technology is a perfect solution to solve this problem because it can maintain an immutable ledger. 
In a Blockchained data storage multiple peers in the network has their own replicated copy of the ledger. In addition to ledger 
information being distributed, the processes which update the ledger require a quorum. Moreover, in a permissioned and private 
blockchain, very specific data and operation access control can be specified. This project, Organ Chain, is a prototype of a web 
based application that tracks an organ from its donation to transplant with blockchain technology.

C. Technologies Used

1.   Hyperledger Fabric?
    - It's private and permissioned
    - Provides comprehensive ACL options
2.   Hyperledger Composer?
    - It simplifies Fabric application development process faster